/* revoke.c - can't quite emulate BSD revoke? - rick sladkey */


int revoke(line)
char *line;
{
	return 0;	
}

