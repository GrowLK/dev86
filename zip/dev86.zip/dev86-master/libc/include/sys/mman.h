
#ifndef __SYS_MMAN_H
#define __SYS_MMAN_H
#include <features.h>
#include __SYSINC__(mman.h)
#endif
